<?php

require_once __DIR__ . '/../app/config/Database.php';
require_once __DIR__ . '/../app/models/Contacto.php';
require_once __DIR__ . '/../app/controllers/ContactoController.php';

try {
    $pdo = (new Database())->conectar();
    $modelo = new Contacto($pdo);
    $controlador = new ContactoController($modelo);
    $controlador->procesar();
} catch (PDOException $e) {
    http_response_code(500);
    exit('No fue posible conectar con la base de datos.');
}