<?php require __DIR__ . '/../layouts/header.php'; ?>

<div class="barra">
    <h2>Contactos registrados</h2>
    <a class="boton" href="index.php?accion=crear">Nuevo contacto</a>
</div>

<?php if ($contactos === []): ?>
    <p>No hay contactos registrados.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Teléfono</th>
                <th>Correo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($contactos as $contacto): ?>
            <tr>
                <td><?= htmlspecialchars($contacto['nombre']) ?></td>
                <td><?= htmlspecialchars($contacto['telefono']) ?></td>
                <td><?= htmlspecialchars($contacto['correo'] ?? '') ?></td>
                <td class="acciones">
                    <a href="index.php?accion=editar&id=<?= (int) $contacto['id'] ?>">
                        Editar
                    </a>

                    <form method="post"
                          action="index.php?accion=eliminar"
                          onsubmit="return confirm('¿Eliminar este contacto?');">
                        <input type="hidden" name="id"
                               value="<?= (int) $contacto['id'] ?>">
                        <button class="enlace-peligro" type="submit">
                            Eliminar
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require __DIR__ . '/../layouts/footer.php'; ?>