<?php require __DIR__ . '/../layouts/header.php'; ?>

<h2><?= htmlspecialchars($titulo) ?></h2>

<?php if ($errores !== []): ?>
    <div class="errores">
        <strong>Revise los siguientes datos:</strong>
        <ul>
        <?php foreach ($errores as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
        <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post">
    <label for="nombre">Nombre</label>
    <input id="nombre" name="nombre" type="text"
           value="<?= htmlspecialchars($contacto['nombre']) ?>" required>

    <label for="telefono">Teléfono</label>
    <input id="telefono" name="telefono" type="text"
           value="<?= htmlspecialchars($contacto['telefono']) ?>" required>

    <label for="correo">Correo</label>
    <input id="correo" name="correo" type="email"
           value="<?= htmlspecialchars($contacto['correo'] ?? '') ?>">

    <button class="boton" type="submit">Guardar</button>
    <a class="boton secundario" href="index.php">Cancelar</a>
</form>

<?php require __DIR__ . '/../layouts/footer.php'; ?> 