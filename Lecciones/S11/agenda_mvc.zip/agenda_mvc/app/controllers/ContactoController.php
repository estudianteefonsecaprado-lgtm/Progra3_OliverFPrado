<?php

class ContactoController
{

    public function __construct(private Contacto $modelo)
    {
    }

    public function procesar(): void
    {
        $accion = $_GET['accion'] ?? 'listar';

        switch ($accion) {
            case 'crear':
                $this->crear();
                break;

            case 'editar':
                $this->editar();
                break;

            case 'eliminar':
                $this->eliminar();
                break;

            default:
                $this->listar();
        }
    }

private function listar(): void
{
    $contactos = $this->modelo->obtenerTodos();
    require __DIR__ . '/../views/contactos/lista.php';
}

private function crear(): void
{
    $contacto = [
        'nombre' => '',
        'telefono' => '',
        'correo' => ''
    ];

    $errores = [];
    $titulo = 'Nuevo Contacto';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $contacto = $this->leerFormulario();
        $errores = $this->validar($contacto);

        if ($errores === []) {
            $this->modelo->crear($contacto);
            $this->redirigir();
        }
    }

    require __DIR__ . '/../views/contactos/formulario.php';

}


    private function editar(): void
    {
        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

        if (!$id || !($contacto = $this->modelo->obtenerPorId($id))) {
            $this->redirigir();
        }

        $errores = [];
        $titulo = 'Editar contacto';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $contacto = $this->leerFormulario();
            $errores = $this->validar($contacto);

            if ($errores === []) {
                $this->modelo->actualizar($id, $contacto);
                $this->redirigir();
            }
        }

        require __DIR__ . '/../views/contactos/formulario.php';
    }

    private function eliminar(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirigir();
        }

        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        if ($id) {
            $this->modelo->eliminar($id);
        }

        $this->redirigir();
    }

    private function leerFormulario(): array
    {
        return [
            'nombre' => trim($_POST['nombre'] ?? ''),
            'telefono' => trim($_POST['telefono'] ?? ''),
            'correo' => trim($_POST['correo'] ?? '')
        ];
    }

    private function validar(array $datos): array
    {
        $errores = [];

        if ($datos['nombre'] === '') {
            $errores[] = 'El nombre es obligatorio.';
        }

        if ($datos['telefono'] === '') {
            $errores[] = 'El teléfono es obligatorio.';
        }

        if ($datos['correo'] !== ''
            && !filter_var($datos['correo'], FILTER_VALIDATE_EMAIL)) {
            $errores[] = 'El correo no tiene un formato válido.';
        }

        return $errores;
    }

    private function redirigir(): never
    {
        header('Location: index.php');
        exit;
    }
}
    ?>