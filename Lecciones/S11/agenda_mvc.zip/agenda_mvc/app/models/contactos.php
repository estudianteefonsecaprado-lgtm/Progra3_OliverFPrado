<?php
class Contacto
{
    public function __construct(private PDO $pdo)
    {
    }

    public function obtenerTodos(): array
    {
        $sql = 'SELECT id, nombre, telefono, correo
                FROM contactos
                ORDER BY nombre ASC';

        return $this->pdo->query($sql)->fetchAll();
    }

    public function obtenerPorId(int $id): array|false
    {
        $sql = 'SELECT id, nombre, telefono, correo
                FROM contactos
                WHERE id = :id';

        $sentencia = $this->pdo->prepare($sql);
        $sentencia->execute(['id' => $id]);

        return $sentencia->fetch();
    }

    public function crear(array $datos): bool
    {
        $sql = 'INSERT INTO contactos (nombre, telefono, correo)
                VALUES (:nombre, :telefono, :correo)';

        $sentencia = $this->pdo->prepare($sql);
        return $sentencia->execute([
            'nombre' => $datos['nombre'],
            'telefono' => $datos['telefono'],
            'correo' => $datos['correo'] ?: null
        ]);
    }

    public function actualizar(int $id, array $datos): bool
    {
        $sql = 'UPDATE contactos
                SET nombre = :nombre,
                    telefono = :telefono,
                    correo = :correo
                WHERE id = :id';

        $sentencia = $this->pdo->prepare($sql);
        return $sentencia->execute([
            'nombre' => $datos['nombre'],
            'telefono' => $datos['telefono'],
            'correo' => $datos['correo'] ?: null,
            'id' => $id
        ]);
    }

    public function eliminar(int $id): bool
    {
        $sentencia = $this->pdo->prepare(
            'DELETE FROM contactos WHERE id = :id'
        );

        return $sentencia->execute(['id' => $id]);
    }
}

?>