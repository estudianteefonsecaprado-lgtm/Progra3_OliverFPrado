<?php

class Database
{
    private string $host = 'localhost';
    private string $baseDatos = 'agenda_db';
    private string $usuario = 'root';
    private string $clave = '';

    public function conectar(): PDO
    {
        $dsn = "mysql:host={$this->host};dbname={$this->baseDatos};charset=utf8mb4";

        $opciones = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ];

        return new PDO($dsn, $this->usuario, $this->clave, $opciones);
    }
}

?>